#ifndef pointtocsv_hpp
#define pointtocsv_hpp

#include <QString>

bool writePointsToCSV(const QString &filename);

#endif /* pointtocsv_hpp */
